/* WEBSERVER ServerAction.java
 * EE422C Project 7 submission by
 * Anthony Bauer
 * amb6869
 * 16480
 * Grant Uy
 * gau84
 * 16480
 * Slip days used: <1>
 * Fall 2016
 */
package assignment7;

/**
 * Created by Anthony on 11/29/2016.
 */
public enum ServerAction {
    LOGINSUCCESS,
    FRIENDS,OFFLINEFRIENDS,STRANGERS,GROUPS,
    MESSAGEHISTORY,GROUPMESSAGEHISTORY,
    FRIENDADDED,FRIENDREMOVED,
    NEWMESSAGE,NEWGROUPMESSAGE,
    COMEONLINE, WENTOFFLINE
}
