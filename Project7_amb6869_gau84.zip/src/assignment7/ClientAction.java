/* WEBSERVER ClientAction.java
 * EE422C Project 7 submission by
 * Anthony Bauer
 * amb6869
 * 16480
 * Grant Uy
 * gau84
 * 16480
 * Slip days used: <1>
 * Fall 2016
 */
package assignment7;

/**
 * Created by Anthony on 11/28/2016.
 */
public enum ClientAction {
    REGISTER,LOGIN,UPDATEPASSWORD,
    SENDMESSAGE,SENDGROUPMESSAGE,MAKECHAT,
    GETMESSAGEHISTORY, GETGROUPMESSAGEHISTORY,
    GETFRIENDS,GETOFFLINEFRIENDS,GETSTRANGERS,GETGROUPS,
    ADDFRIEND,REMOVEFRIEND, LEAVEGROUP
}
