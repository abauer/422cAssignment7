Anthony Bauer - amb6869
Grant Uy - gau84

List of .java files we are submitting:
Client.java
Contact.java
ClientAction.java
ServerAction.java
DatabaseServer.java
DatabaseAccessor.java
MultiThreadServer.java
Parser.java

We tested multiple clients on several Windows environments.

Git URL:
https://github.com/abauer/422cAssignment7